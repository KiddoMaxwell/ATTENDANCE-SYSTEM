﻿
Imports System.Data.SqlClient
Public Class AdminEmpAttendanceForm
    Private Sub AdminEmpAttendanceForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EmpattendanceDBDataSet.AttendanceRecord' table. You can move, or remove it, as needed.
        Me.AttendanceRecordTableAdapter.Fill(Me.EmpattendanceDBDataSet.AttendanceRecord)

        Me.BindData()
    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged
        Dim query As String = "SELECT * FROM AttendanceRecord WHERE USERNAME LIKE'%" & TextBox4.Text & "%'"
        Using con As SqlConnection = New SqlConnection("Data Source=STALKER01\SQLEXPRESSSS;Initial Catalog=attendanceDB;Integrated Security=True;Pooling=False")
            Using cmd As SqlCommand = New SqlCommand(query, con)
                Using sda As New SqlDataAdapter()
                    sda.SelectCommand = cmd
                    Using dt As New DataTable()
                        sda.Fill(dt)
                        If dt.Rows.Count > 0 Then
                            DataGridView1.DataSource = dt
                        Else
                            MessageBox.Show("No record found!")
                        End If

                    End Using
                End Using
            End Using
        End Using
    End Sub
    Private Sub BindData()
        Dim query As String = "SELECT * FROM AttendanceRecord"
        Using con As SqlConnection = New SqlConnection("Data Source=STALKER01\SQLEXPRESSSS;Initial Catalog=attendanceDB;Integrated Security=True;Pooling=False")
            Using cmd As SqlCommand = New SqlCommand(query, con)
                Using sda As New SqlDataAdapter()
                    sda.SelectCommand = cmd
                    Using dt As New DataTable()
                        sda.Fill(dt)
                        DataGridView1.DataSource = dt
                    End Using
                End Using
            End Using
        End Using
    End Sub
End Class